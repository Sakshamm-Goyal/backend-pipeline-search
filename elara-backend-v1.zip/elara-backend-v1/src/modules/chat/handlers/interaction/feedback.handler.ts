import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Observable, Subscriber } from 'rxjs';
import {
  IChatHandler,
  ChatChunk,
  ChatIntent,
  UserContext,
} from '../handler.interface';
import { ConversationContext } from '../../../pipeline/agents/dto/chat-message.dto';
import { SearchFilters } from '../../../pipeline/search/dto/search-query.dto';
import { ProductFeedback } from '../../domain/schemas/feedback.schema';

/**
 * Feedback Handler
 *
 * Handles user feedback on products and outfits.
 * Stores feedback for personalization and learning.
 *
 * Examples:
 * - "I love this outfit!"
 * - "The shoes aren't my style"
 * - "Too expensive for me"
 * - "This is perfect"
 */
@Injectable()
export class FeedbackHandler implements IChatHandler {
  private readonly logger = new Logger(FeedbackHandler.name);

  constructor(
    @InjectModel(ProductFeedback.name)
    private feedbackModel: Model<ProductFeedback>,
  ) {}

  canHandle(intent: ChatIntent): boolean {
    return intent === ChatIntent.FEEDBACK;
  }

  handle(
    message: string,
    context: ConversationContext,
    filters?: SearchFilters,
    userContext?: UserContext,
  ): Observable<ChatChunk> {
    return new Observable((observer) => {
      this.processFeedback(message, context, userContext, observer);
    });
  }

  private async processFeedback(
    message: string,
    context: ConversationContext,
    userContext: UserContext | undefined,
    observer: Subscriber<ChatChunk>,
  ): Promise<void> {
    try {
      // Parse feedback sentiment
      const { sentiment, reason, productUrl } = this.parseFeedback(message, context);

      // Save feedback to database
      if (productUrl) {
        await this.feedbackModel.findOneAndUpdate(
          {
            userId: context.userId,
            productUrl,
          },
          {
            $set: {
              feedback: sentiment,
              reason,
              updatedAt: new Date(),
            },
          },
          { upsert: true, new: true },
        );

        this.logger.log(`Saved ${sentiment} feedback for ${context.userId}`);
      }

      // Generate response based on sentiment
      const response = this.generateFeedbackResponse(sentiment, reason);

      observer.next({
        type: 'text',
        text: response.message,
      });

      observer.next({
        type: 'data',
        data: {
          feedbackSaved: true,
          sentiment,
          suggestedActions: response.actions,
        },
        done: true,
      });

      observer.complete();
    } catch (error) {
      this.logger.error(`Feedback processing failed: ${(error as Error).message}`);
      observer.next({
        type: 'text',
        text: "Thanks for your feedback! I'll keep that in mind.",
      });
      observer.next({
        type: 'data',
        data: { feedbackSaved: false },
        done: true,
      });
      observer.complete();
    }
  }

  private parseFeedback(
    message: string,
    context: ConversationContext,
  ): {
    sentiment: 'like' | 'dislike';
    reason?: string;
    productUrl?: string;
  } {
    const messageLower = message.toLowerCase();

    // Determine sentiment
    const positiveKeywords = [
      'love', 'like', 'perfect', 'great', 'amazing', 'beautiful',
      'gorgeous', 'stunning', 'yes', 'good', 'nice', 'awesome',
    ];
    const negativeKeywords = [
      'hate', 'dislike', "don't like", 'not my', 'ugly', 'bad',
      'terrible', 'no', 'wrong', 'too expensive', 'not right',
    ];

    let sentiment: 'like' | 'dislike' = 'like';
    if (negativeKeywords.some((kw) => messageLower.includes(kw))) {
      sentiment = 'dislike';
    } else if (!positiveKeywords.some((kw) => messageLower.includes(kw))) {
      // Default to like if neutral
      sentiment = 'like';
    }

    // Extract reason
    let reason: string | undefined;
    const reasonPatterns = [
      /because (.+)/i,
      /too (.+)/i,
      /not (.+) enough/i,
      /I prefer (.+)/i,
    ];

    for (const pattern of reasonPatterns) {
      const match = message.match(pattern);
      if (match) {
        reason = match[1].trim();
        break;
      }
    }

    // Try to get product URL from context (last shown product/outfit)
    let productUrl: string | undefined;
    const lastOutfits = context.metadata?.lastOutfits || [];
    if (lastOutfits.length > 0) {
      // Get the first item from the first outfit
      const firstOutfit = lastOutfits[0];
      if (firstOutfit?.items?.[0]?.url) {
        productUrl = firstOutfit.items[0].url;
      }
    }

    return { sentiment, reason, productUrl };
  }

  private generateFeedbackResponse(
    sentiment: 'like' | 'dislike',
    reason?: string,
  ): {
    message: string;
    actions: Array<{ label: string; action: string }>;
  } {
    if (sentiment === 'like') {
      return {
        message: reason
          ? `I'm glad you like it! I'll remember that ${reason} works well for you.`
          : "Great choice! I'll remember this for future recommendations.",
        actions: [
          { label: 'Save to favorites', action: 'save_favorite' },
          { label: 'Find similar items', action: 'find_similar' },
          { label: 'Create outfit with this', action: 'create_outfit' },
        ],
      };
    }

    return {
      message: reason
        ? `Got it! I'll avoid ${reason} in future suggestions. Would you like me to find something different?`
        : "Thanks for letting me know! Let me find something better for you.",
      actions: [
        { label: 'Show alternatives', action: 'show_alternatives' },
        { label: 'Refine search', action: 'refine_search' },
        { label: 'Try different style', action: 'new_search' },
      ],
    };
  }
}
