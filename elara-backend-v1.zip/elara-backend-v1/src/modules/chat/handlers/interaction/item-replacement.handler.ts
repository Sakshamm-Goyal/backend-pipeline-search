import { Injectable, Logger } from '@nestjs/common';
import { Observable, Subscriber } from 'rxjs';
import {
  IChatHandler,
  ChatChunk,
  ChatIntent,
  UserContext,
} from '../handler.interface';
import { ConversationContext } from '../../../pipeline/agents/dto/chat-message.dto';
import { SearchFilters, buildSearchQuery } from '../../../pipeline/search/dto/search-query.dto';
import { SearchOrchestratorService } from '../../../pipeline/search/search-orchestrator.service';
import { ClaudeService } from '../../../pipeline/infrastructure/llm/claude.service';

/**
 * Item Replacement Handler
 *
 * Handles requests to replace items in previously shown outfits.
 * Uses Claude to parse which item to replace, then searches for alternatives.
 *
 * Examples:
 * - "Replace the shoes in outfit 2"
 * - "Show me a different top"
 * - "I don't like the pants, find something else"
 */
@Injectable()
export class ItemReplacementHandler implements IChatHandler {
  private readonly logger = new Logger(ItemReplacementHandler.name);

  constructor(
    private searchOrchestrator: SearchOrchestratorService,
    private claudeService: ClaudeService,
  ) {}

  canHandle(intent: ChatIntent): boolean {
    return intent === ChatIntent.ITEM_REPLACEMENT;
  }

  handle(
    message: string,
    context: ConversationContext,
    filters?: SearchFilters,
    userContext?: UserContext,
  ): Observable<ChatChunk> {
    return new Observable((observer) => {
      this.executeReplacement(message, context, filters, userContext, observer);
    });
  }

  private async executeReplacement(
    message: string,
    context: ConversationContext,
    filters: SearchFilters | undefined,
    userContext: UserContext | undefined,
    observer: Subscriber<ChatChunk>,
  ): Promise<void> {
    try {
      // Step 1: Parse what to replace
      observer.next({
        type: 'status',
        status: 'parsing',
        text: 'Understanding what to replace...',
      });

      const replacement = await this.parseReplacementRequest(message, context);

      if (!replacement) {
        observer.next({
          type: 'text',
          text: "I couldn't understand which item you'd like to replace. Could you specify the item (shoes, top, bottom, etc.) and which outfit?",
        });
        observer.next({ type: 'data', data: {}, done: true });
        observer.complete();
        return;
      }

      const { outfitIndex, itemSlot, excludeUrls } = replacement;

      // Step 2: Check if we have the previous outfit
      const previousOutfits = context.metadata?.lastOutfits || [];
      if (outfitIndex >= previousOutfits.length) {
        observer.next({
          type: 'text',
          text: `I don't have outfit ${outfitIndex + 1} in my memory. Could you search for a new outfit first?`,
        });
        observer.next({ type: 'data', data: {}, done: true });
        observer.complete();
        return;
      }

      const previousOutfit = previousOutfits[outfitIndex];

      // Step 3: Search for replacement
      observer.next({
        type: 'status',
        status: 'searching',
        text: `Finding alternative ${itemSlot}...`,
      });

      const searchQuery = buildSearchQuery(
        `${itemSlot} ${previousOutfit.style || ''}`,
        {
          ...filters,
          itemType: itemSlot,
        },
        userContext,
      );
      searchQuery.limit = 10;

      const result = await this.searchOrchestrator.search(searchQuery, userContext);

      // Filter out the original item
      const alternatives = result.products.filter(
        (p) => !excludeUrls.includes(p.productUrl),
      );

      if (alternatives.length === 0) {
        observer.next({
          type: 'text',
          text: `I couldn't find alternative ${itemSlot}. Would you like to search with different criteria?`,
        });
        observer.next({ type: 'data', data: {}, done: true });
        observer.complete();
        return;
      }

      // Step 4: Create updated outfit with replacement
      const newItem = alternatives[0];
      const updatedOutfit = this.createUpdatedOutfit(
        previousOutfit,
        itemSlot,
        newItem,
      );

      observer.next({
        type: 'text',
        text: `Here's your outfit with a new ${itemSlot}:`,
      });

      observer.next({
        type: 'data',
        data: {
          outfit: updatedOutfit,
          alternatives: alternatives.slice(1, 5), // Show a few more options
          replacedSlot: itemSlot,
        },
        done: true,
      });

      this.logger.log(`Replaced ${itemSlot} in outfit ${outfitIndex + 1}`);

      observer.complete();
    } catch (error) {
      this.logger.error(`Replacement failed: ${(error as Error).message}`);
      observer.next({
        type: 'text',
        text: "I'm having trouble finding replacements. Please try again.",
      });
      observer.error(error);
    }
  }

  private async parseReplacementRequest(
    message: string,
    context: ConversationContext,
  ): Promise<{
    outfitIndex: number;
    itemSlot: string;
    excludeUrls: string[];
  } | null> {
    const messageLower = message.toLowerCase();

    // Extract outfit number (default to 0 if not specified)
    let outfitIndex = 0;
    const outfitMatch = messageLower.match(/outfit\s*(\d+)/);
    if (outfitMatch) {
      outfitIndex = parseInt(outfitMatch[1], 10) - 1; // Convert to 0-indexed
    }

    // Extract item slot
    const slotKeywords: Record<string, string[]> = {
      top: ['top', 'shirt', 'blouse', 'tee', 't-shirt', 'sweater'],
      bottom: ['bottom', 'pants', 'jeans', 'skirt', 'shorts', 'trousers'],
      shoes: ['shoes', 'footwear', 'sneakers', 'boots', 'heels', 'sandals'],
      dress: ['dress', 'gown'],
      outerwear: ['jacket', 'coat', 'blazer', 'cardigan', 'outerwear'],
      accessories: ['accessories', 'bag', 'belt', 'jewelry', 'watch'],
    };

    let itemSlot: string | null = null;
    for (const [slot, keywords] of Object.entries(slotKeywords)) {
      if (keywords.some((kw) => messageLower.includes(kw))) {
        itemSlot = slot;
        break;
      }
    }

    if (!itemSlot) {
      // If no specific slot mentioned, check if we can infer from context
      // or return null to ask for clarification
      return null;
    }

    // Get URLs to exclude from previous outfit
    const previousOutfits = context.metadata?.lastOutfits || [];
    const excludeUrls: string[] = [];

    if (previousOutfits[outfitIndex]) {
      const items = previousOutfits[outfitIndex].items || [];
      const currentItem = items.find(
        (item: any) => item.category === itemSlot,
      );
      if (currentItem?.url) {
        excludeUrls.push(currentItem.url);
      }
    }

    return { outfitIndex, itemSlot, excludeUrls };
  }

  private createUpdatedOutfit(
    previousOutfit: any,
    slotToReplace: string,
    newItem: any,
  ): any {
    const updatedItems = (previousOutfit.items || []).map((item: any) => {
      if (item.category === slotToReplace) {
        return {
          category: slotToReplace,
          name: newItem.title,
          price: `$${newItem.price?.toFixed(2) || '0.00'}`,
          url: newItem.productUrl,
          image_url: newItem.imageUrl,
          retailer: newItem.retailer,
          product_id: newItem.id,
          brand: newItem.brand,
          isReplacement: true,
        };
      }
      return item;
    });

    // Recalculate total price
    const totalPrice = updatedItems.reduce((sum: number, item: any) => {
      const price = parseFloat(item.price?.replace('$', '') || '0');
      return sum + price;
    }, 0);

    return {
      ...previousOutfit,
      items: updatedItems,
      total_price: `$${totalPrice.toFixed(2)}`,
      reasoning: `Updated outfit with new ${slotToReplace}.`,
    };
  }
}
