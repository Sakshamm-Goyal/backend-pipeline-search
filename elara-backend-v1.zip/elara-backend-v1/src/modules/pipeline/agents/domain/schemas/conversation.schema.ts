import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

// Sub-document for chat messages
@Schema({ _id: false })
export class ChatMessage {
  @Prop({ required: true })
  id!: string;

  @Prop({ required: true, enum: ['user', 'assistant', 'system'] })
  role!: 'user' | 'assistant' | 'system';

  @Prop({ required: true })
  content!: string;

  @Prop({ required: true })
  timestamp!: Date;

  @Prop({ type: Object })
  metadata?: Record<string, any>;
}

const ChatMessageSchema = SchemaFactory.createForClass(ChatMessage);

// Sub-document for user context
@Schema({ _id: false })
export class UserContext {
  @Prop()
  gender?: string;

  @Prop()
  style?: string;

  @Prop()
  preferences?: string;

  @Prop({ type: [String], default: [] })
  budget?: string[];

  @Prop({ type: [String], default: [] })
  occasions?: string[];

  @Prop({ type: Object })
  other?: Record<string, any>;
}

const UserContextSchema = SchemaFactory.createForClass(UserContext);

// Sub-document for conversation metadata
@Schema({ _id: false })
export class ConversationMetadata {
  @Prop({ required: true })
  startedAt!: Date;

  @Prop({ required: true })
  lastMessageAt!: Date;

  @Prop({ required: true, default: 0 })
  messageCount!: number;

  @Prop()
  lastIntent?: string;

  @Prop()
  sessionId?: string;
}

const ConversationMetadataSchema = SchemaFactory.createForClass(ConversationMetadata);

@Schema({
  timestamps: true,
  collection: 'conversations',
  toJSON: {
    virtuals: true,
    transform: (doc, ret: any) => {
      ret.id = ret._id.toString();
      delete ret._id;
      delete ret.__v;
      return ret;
    },
  },
})
export class Conversation extends Document {
  @Prop({ required: true, unique: true, index: true })
  conversationId!: string; // UUID from chat orchestrator

  @Prop({ required: true, type: Types.ObjectId, ref: 'User', index: true })
  userId!: Types.ObjectId;

  @Prop()
  sessionId?: string;

  @Prop({ type: [ChatMessageSchema], default: [] })
  history!: ChatMessage[];

  @Prop()
  currentIntent?: string;

  @Prop({ type: UserContextSchema })
  userContext?: UserContext;

  @Prop({ type: ConversationMetadataSchema, required: true })
  metadata!: ConversationMetadata;

  @Prop({ default: true })
  isActive!: boolean;

  @Prop()
  deletedAt?: Date;

  // Timestamps (automatically added by timestamps: true)
  createdAt!: Date;
  updatedAt!: Date;
}

export const ConversationSchema = SchemaFactory.createForClass(Conversation);

// Indexes for efficient querying
ConversationSchema.index({ conversationId: 1 }, { unique: true });
ConversationSchema.index({ userId: 1, isActive: 1 });
ConversationSchema.index({ userId: 1, 'metadata.lastMessageAt': -1 });
ConversationSchema.index({ createdAt: -1 });
ConversationSchema.index({ isActive: 1, deletedAt: 1 });

// TTL index for soft-deleted conversations (optional: delete after 30 days)
ConversationSchema.index(
  { deletedAt: 1 },
  { expireAfterSeconds: 30 * 24 * 60 * 60, partialFilterExpression: { deletedAt: { $exists: true } } },
);
