import { Injectable, Logger } from '@nestjs/common';
import { GeminiService } from '../../infrastructure/llm/gemini.service';
import { SearchOrchestratorService } from '../../search/search-orchestrator.service';
import { buildSearchQuery } from '../../search/dto/search-query.dto';
import { Product } from '../../search/dto/product.dto';
import { AgentResponse, ResponseType } from '../dto/chat-message.dto';
import { RoutingDecision } from './intent-router.service';
import {
  OutfitRecommendationScoringService,
  ScoringContext,
} from '../../outfit-scoring/services/outfit-recommendation-scoring.service';

/**
 * Outfit Generator Agent
 *
 * Creates complete outfit recommendations using AI.
 * Combines SearchOrchestrator for product discovery with
 * Gemini for intelligent outfit combination.
 *
 * ENHANCED: Now follows Python pipeline pattern:
 * - Returns exactly 3 outfits
 * - Each outfit has 5-6 items (men) or 7-8 items (women)
 * - Mandatory accessories (2-3 for men, 4-5 for women)
 * - Uses deterministic scoring matrix
 *
 * Workflow:
 * 1. Search for products in each clothing slot
 * 2. Group products by slot (top, bottom, shoes, accessories, etc.)
 * 3. Use Gemini to generate 3 outfit combinations
 * 4. Score each outfit using deterministic scoring matrix
 * 5. Format and present to user (sorted by score)
 */
@Injectable()
export class OutfitGeneratorAgentService {
  private readonly logger = new Logger(OutfitGeneratorAgentService.name);

  // Minimum items per outfit (men: 5-6, women: 7-8)
  private readonly MIN_ITEMS_MEN = 5;
  private readonly MIN_ITEMS_WOMEN = 7;
  private readonly TARGET_OUTFITS = 3;

  // Clothing slots for outfit building - ENHANCED with accessories
  private readonly CLOTHING_SLOTS = [
    'top',
    'bottom',
    'dress',
    'shoes',
    'outerwear',
    'accessories',
  ];

  // Accessory types for men and women
  private readonly ACCESSORY_TYPES_MEN = ['watch', 'belt', 'sunglasses', 'bag', 'hat'];
  private readonly ACCESSORY_TYPES_WOMEN = ['bag', 'jewelry', 'sunglasses', 'belt', 'scarf', 'watch'];

  constructor(
    private geminiService: GeminiService,
    private searchOrchestrator: SearchOrchestratorService,
    private scoringService: OutfitRecommendationScoringService,
  ) {}

  /**
   * Generate outfit recommendations
   * ENHANCED: Now returns exactly 3 outfits with 5-6 items each, scored and ranked
   */
  async execute(
    message: string,
    routing: RoutingDecision,
    userContext?: any,
  ): Promise<AgentResponse> {
    const startTime = Date.now();

    try {
      this.logger.log(`Generating outfit recommendations for: "${message}"`);

      // Determine gender for item count requirements
      const gender = userContext?.gender?.toLowerCase() || 'men';
      const minItems = gender === 'women' ? this.MIN_ITEMS_WOMEN : this.MIN_ITEMS_MEN;

      // Step 1: Search for products in each slot (including accessories)
      const slotProducts = await this.searchProductsBySlot(
        message,
        routing.filters,
        userContext,
      );

      // Check if we have enough products
      const totalProducts = Array.from(slotProducts.values()).reduce(
        (sum, products) => sum + products.length,
        0,
      );

      if (totalProducts < 3) {
        return this.buildInsufficientProductsResponse();
      }

      // Step 2: Generate outfit combinations using Gemini
      let outfits = await this.geminiService.generateOutfitRecommendations(
        message,
        userContext,
        slotProducts,
        routing.filters,
      );

      if (outfits.length === 0) {
        return this.buildNoOutfitsResponse();
      }

      // Step 3: Ensure we have exactly 3 outfits with proper item counts
      outfits = this.ensureCompleteOutfits(outfits, slotProducts, minItems, gender);

      // Step 4: Score and rank outfits using deterministic scoring matrix
      const scoringContext = this.buildScoringContext(userContext, routing.filters);
      const scoredOutfits = this.scoringService.scoreAndRankOutfits(
        outfits.map((o: any) => ({
          ...o,
          items: (o.items || []).map((item: any) => {
            const slotName = item.slot || item.category;
            const products = slotProducts.get(slotName) || [];
            const product = products.find(
              (p) => p.id === item.productId || p.sourceId === item.productId,
            );
            return {
              slot: slotName,
              name: product?.title || item.productId,
              source: product?.retailer || 'Unknown',
              retailer: product?.retailer || 'Unknown',
              price: product?.price
                ? { value: product.price, currency: product.currency || 'USD' }
                : undefined,
            };
          }),
        })),
        scoringContext,
      );

      // Step 5: Take top 3 outfits
      const top3Outfits = scoredOutfits.slice(0, this.TARGET_OUTFITS);

      this.logger.log(
        `Generated ${top3Outfits.length} outfits, scores: ${top3Outfits.map((o) => o.score).join(', ')}`,
      );

      // Step 6: Format response (pass slotProducts for product lookup)
      const response = this.formatOutfitResponse(message, top3Outfits, slotProducts);

      // Add metadata
      response.metadata = {
        intent: routing.intent,
        confidence: routing.confidence,
        agentUsed: 'outfit_generator',
        processingTime: Date.now() - startTime,
        outfitCount: top3Outfits.length,
        scores: top3Outfits.map((o) => o.score),
      };

      this.logger.log(
        `Generated ${top3Outfits.length} scored outfits in ${Date.now() - startTime}ms`,
      );

      return response;
    } catch (error) {
      this.logger.error(
        `Outfit generation failed: ${(error as Error).message}`,
      );

      return {
        message: "I'm having trouble creating outfits right now. Let me show you individual products instead.",
        type: ResponseType.ERROR,
        metadata: {
          intent: routing.intent,
          confidence: routing.confidence,
          agentUsed: 'outfit_generator',
          processingTime: Date.now() - startTime,
        },
      };
    }
  }

  /**
   * Build scoring context from user context and filters
   */
  private buildScoringContext(userContext: any, filters: any): ScoringContext {
    return {
      session: {
        occasion: filters?.occasion || userContext?.occasion || 'casual',
        vibe: filters?.vibe || userContext?.vibe || 'casual',
        location: userContext?.location,
      },
      user_profile: {
        gender: userContext?.gender,
        skin_tone: userContext?.skin_tone,
        body_type: userContext?.body_type,
        fit_pref: userContext?.fit_pref,
        color_prefs: userContext?.color_prefs || [],
        brand_prefs: userContext?.brand_prefs || [],
      },
      derived: {
        temp_band: this.deriveTempBand(userContext?.weather),
        rain: userContext?.weather?.precipitation > 0,
      },
      constraints: {
        budget: {
          soft_cap: filters?.maxPrice || userContext?.budget?.soft_cap || 150,
          hard_cap: (filters?.maxPrice || 150) * 2,
        },
      },
      trend_tags: [
        { tag: 'minimalist', w: 0.5 },
        { tag: 'neutral', w: 0.5 },
        { tag: 'relaxed-fit', w: 0.3 },
        { tag: 'linen', w: 0.3 },
      ],
    };
  }

  /**
   * Derive temperature band from weather data
   */
  private deriveTempBand(weather: any): 'cold' | 'cool' | 'mild' | 'warm' {
    const temp = weather?.temp_c || weather?.temperature || 20;
    if (temp <= 10) return 'cold';
    if (temp <= 18) return 'cool';
    if (temp <= 24) return 'mild';
    return 'warm';
  }

  /**
   * Ensure outfits have minimum required items
   * Adds accessories if needed to meet minimum
   */
  private ensureCompleteOutfits(
    outfits: any[],
    slotProducts: Map<string, Product[]>,
    minItems: number,
    gender: string,
  ): any[] {
    const accessoryTypes = gender === 'women'
      ? this.ACCESSORY_TYPES_WOMEN
      : this.ACCESSORY_TYPES_MEN;

    return outfits.map((outfit, index) => {
      const items = outfit.items || [];

      // If outfit doesn't have enough items, add accessories
      if (items.length < minItems) {
        const accessories = slotProducts.get('accessories') || [];
        const accessoriesNeeded = minItems - items.length;

        // Add random accessories that aren't already in the outfit
        const existingIds = new Set(items.map((i: any) => i.productId));
        const availableAccessories = accessories.filter(
          (a) => !existingIds.has(a.id),
        );

        for (let i = 0; i < accessoriesNeeded && i < availableAccessories.length; i++) {
          const acc = availableAccessories[i];
          items.push({
            slot: 'accessory',
            productId: acc.id,
            selectionReason: 'Added to complete outfit',
          });
        }

        this.logger.debug(
          `Added ${Math.min(accessoriesNeeded, availableAccessories.length)} accessories to outfit ${index + 1}`,
        );
      }

      return { ...outfit, items };
    });
  }

  /**
   * Search for products in each clothing slot
   * CRITICAL: Uses slot-specific search terms for relevant results
   */
  private async searchProductsBySlot(
    query: string,
    filters: any,
    userContext?: any,
  ): Promise<Map<string, Product[]>> {
    const slotProducts = new Map<string, Product[]>();

    // Determine which slots to search based on query
    const slotsToSearch = this.determineSlotsToSearch(query, filters);

    this.logger.debug(`Searching slots: ${slotsToSearch.join(', ')}`);

    // Search each slot in parallel with SLOT-SPECIFIC search terms
    const searchPromises = slotsToSearch.map(async (slot) => {
      try {
        // Build slot-specific search terms (not the original query!)
        const slotSearchTerms = this.buildSlotSearchTerms(slot, filters, userContext);

        this.logger.debug(`Slot "${slot}" search terms: "${slotSearchTerms}"`);

        // Create slot-specific filters (override itemType with slot-appropriate term)
        const slotFilters = {
          ...filters,
          itemType: slotSearchTerms, // Override with slot-specific term
          category: slot,
        };

        const slotQuery = buildSearchQuery(
          slotSearchTerms, // Use slot-specific terms, not original query
          slotFilters,
          userContext,
        );

        slotQuery.limit = 15; // Get 15 per slot

        const results = await this.searchOrchestrator.search(
          slotQuery,
          userContext,
        );

        if (results.products.length > 0) {
          slotProducts.set(slot, results.products);
          this.logger.debug(`Slot "${slot}": found ${results.products.length} products`);
        } else {
          this.logger.warn(`Slot "${slot}": no products found`);
        }
      } catch (error) {
        this.logger.warn(
          `Failed to search slot ${slot}: ${(error as Error).message}`,
        );
      }
    });

    await Promise.allSettled(searchPromises);

    return slotProducts;
  }

  /**
   * Build slot-specific search terms based on the occasion and style
   * This ensures each slot gets relevant products (not dresses for shoes slot!)
   */
  private buildSlotSearchTerms(slot: string, filters: any, userContext?: any): string {
    const occasion = filters.occasion || 'casual';
    const style = filters.style || '';
    const gender = userContext?.profile?.gender?.toLowerCase() || 'women';
    const size = filters.size || '';

    // Occasion-based slot mappings for better search results
    const occasionSlotMap: Record<string, Record<string, string>> = {
      cocktail: {
        dress: 'cocktail dress evening dress',
        shoes: 'evening heels dress shoes',
        accessories: 'evening clutch bag',
        jewelry: 'statement jewelry earrings',
        clutch: 'evening clutch purse',
      },
      party: {
        dress: 'party dress evening dress',
        shoes: 'party heels strappy heels',
        accessories: 'evening bag clutch',
        jewelry: 'party jewelry statement',
        clutch: 'party clutch metallic',
      },
      formal: {
        dress: 'formal gown evening dress',
        shoes: 'formal heels dress shoes',
        accessories: 'formal clutch evening bag',
        jewelry: 'elegant jewelry pearls',
        clutch: 'formal evening clutch',
      },
      wedding: {
        dress: 'wedding guest dress formal',
        shoes: 'wedding guest heels elegant',
        accessories: 'wedding guest clutch',
        jewelry: 'elegant jewelry occasion',
        clutch: 'wedding clutch satin',
      },
      casual: {
        dress: 'casual dress day dress',
        top: 'casual top blouse',
        bottom: 'casual pants jeans',
        shoes: 'casual sneakers flats',
        accessories: 'casual bag tote',
        outerwear: 'casual jacket cardigan',
      },
      date: {
        dress: 'date night dress romantic',
        shoes: 'date night heels elegant',
        accessories: 'evening bag small',
        jewelry: 'delicate jewelry',
        clutch: 'small clutch evening',
      },
      work: {
        dress: 'work dress office professional',
        top: 'work blouse professional',
        bottom: 'work pants trousers',
        shoes: 'work heels professional',
        accessories: 'work bag tote',
        outerwear: 'blazer professional',
      },
    };

    // Get occasion-specific term or use generic
    const occasionTerms = occasionSlotMap[occasion.toLowerCase()] || occasionSlotMap.casual;
    let searchTerm = occasionTerms[slot] || `${gender} ${slot}`;

    // Add style modifier ONLY for clothing items (not accessories/jewelry)
    const clothingSlots = ['dress', 'top', 'bottom', 'outerwear'];
    if (style && clothingSlots.includes(slot) && !searchTerm.includes(style)) {
      searchTerm = `${style} ${searchTerm}`;
    }

    // Add size ONLY for dresses (important for plus-size!)
    if (slot === 'dress' && size) {
      searchTerm = `${searchTerm} ${size}`;
    }

    // Add features like sleeves ONLY for dresses
    if (slot === 'dress' && filters.features?.length) {
      searchTerm = `${searchTerm} ${filters.features.join(' ')}`;
    }

    return searchTerm;
  }

  /**
   * Determine which slots to search based on query and filters
   * CRITICAL: Check for dress/gown FIRST before occasion to ensure correct slots
   */
  private determineSlotsToSearch(query: string, filters: any): string[] {
    const queryLower = query.toLowerCase();
    const itemType = (filters.itemType || '').toLowerCase();

    // CRITICAL: Check for dress/gown FIRST - these are complete garments
    // Must check before occasion because "cocktail dress for event" has both
    const isDressRequest =
      queryLower.includes('dress') ||
      queryLower.includes('gown') ||
      itemType.includes('dress') ||
      itemType.includes('gown');

    if (isDressRequest) {
      this.logger.debug('Detected dress request - searching dress, shoes, accessories, jewelry');
      return ['dress', 'shoes', 'accessories', 'jewelry', 'clutch'];
    }

    // If specific occasion without dress, search separates
    if (filters.occasion) {
      this.logger.debug(`Occasion "${filters.occasion}" - searching separates`);
      return ['top', 'bottom', 'shoes', 'outerwear', 'accessories'];
    }

    // Default: top, bottom, shoes + accessories (for complete outfits)
    return ['top', 'bottom', 'shoes', 'accessories'];
  }

  /**
   * Format outfit response
   * Maps to Python frontend expected format for compatibility
   */
  private formatOutfitResponse(
    query: string,
    outfits: any[],
    slotProducts: Map<string, Product[]>,
  ): AgentResponse {
    const message = this.generateOutfitMessage(outfits.length);

    return {
      message,
      type: ResponseType.OUTFIT_RECOMMENDATIONS,
      data: {
        outfits: outfits.map((outfit, index) => this.formatOutfit(outfit, index, slotProducts)),
        query,
      },
      suggestedActions: [
        {
          label: 'Save favorite',
          action: 'save_outfit',
        },
        {
          label: 'Modify outfit',
          action: 'modify_outfit',
        },
        {
          label: 'Create more outfits',
          action: 'generate_more',
        },
      ],
    };
  }

  /**
   * Generate natural outfit message
   */
  private generateOutfitMessage(count: number): string {
    if (count === 1) {
      return "I've created a complete outfit for you!";
    } else if (count === 2) {
      return "I've created 2 outfit options for you to choose from!";
    } else {
      return `I've created ${count} outfit combinations just for you!`;
    }
  }

  /**
   * Format single outfit for Python frontend compatibility
   * ENHANCED: Now includes score from deterministic scoring matrix
   */
  private formatOutfit(outfit: any, index: number, slotProducts: Map<string, Product[]>): any {
    // Map items to Python frontend format
    const formattedItems = (outfit.items || []).map((item: any) => {
      // Find the actual product from slotProducts
      const slotName = item.slot || item.category;
      const products = slotProducts.get(slotName) || [];

      // Try multiple matching strategies
      let product = this.findProductMatch(item, products, slotName);

      if (product) {
        return {
          // Python frontend expected fields
          slot: slotName,
          category: slotName,
          name: product.title,
          price: product.price ? `$${product.price.toFixed(2)}` : 'Price unavailable',
          priceValue: product.price || 0,
          url: product.productUrl,
          productUrl: product.productUrl,
          image_url: product.imageUrl,
          imageUrl: product.imageUrl,
          retailer: product.retailer,
          product_id: product.id,
          // Additional fields
          brand: product.brand,
          selectionReason: item.selectionReason,
        };
      }

      // Fallback: Use first available product from slot if Gemini's ID doesn't match
      this.logger.warn(`Product "${item.productId}" not found in slot "${slotName}", using fallback`);
      const fallbackProduct = products[0];
      if (fallbackProduct) {
        return {
          slot: slotName,
          category: slotName,
          name: fallbackProduct.title,
          price: fallbackProduct.price ? `$${fallbackProduct.price.toFixed(2)}` : 'Price unavailable',
          priceValue: fallbackProduct.price || 0,
          url: fallbackProduct.productUrl,
          productUrl: fallbackProduct.productUrl,
          image_url: fallbackProduct.imageUrl,
          imageUrl: fallbackProduct.imageUrl,
          retailer: fallbackProduct.retailer,
          product_id: fallbackProduct.id,
          brand: fallbackProduct.brand,
          selectionReason: item.selectionReason || 'Selected as best match for your style',
        };
      }

      // Final fallback if no products at all
      return {
        slot: slotName,
        category: slotName,
        name: item.productId || 'Item unavailable',
        price: 'Price unavailable',
        priceValue: 0,
        url: '',
        productUrl: '',
        image_url: '',
        imageUrl: '',
        retailer: 'Unknown',
        product_id: item.productId,
      };
    });

    // Calculate total price
    const totalPrice = formattedItems.reduce((sum: number, item: any) => {
      return sum + (item.priceValue || 0);
    }, 0);

    return {
      // Python frontend expected fields
      id: `outfit_${index + 1}`,
      outfit_id: index + 1,
      name: outfit.name || `Outfit ${index + 1}`,
      summary: outfit.styleNotes || outfit.occasionFit || 'Stylish outfit for your occasion',
      items: formattedItems,
      total_price: `$${totalPrice.toFixed(2)}`,
      totalPrice: totalPrice,

      // ENHANCED: Score from deterministic scoring matrix (0-10 scale)
      score: outfit.score || 0,
      scoreComponents: outfit.scoreComponents,

      // Reasoning object (matches Python pipeline)
      reasoning: {
        occasion: outfit.occasionFit || 'Appropriate for the occasion',
        weather: outfit.weatherFit || 'Temperature-appropriate fabrics',
        color: outfit.colorHarmony || 'Complementary colors',
        fit: outfit.fitNotes || 'Flattering silhouette',
        trend: outfit.trendAlignment || 'Current fashion trends',
      },

      // Additional fields for enhanced frontend
      style: outfit.style,
      colorScheme: outfit.colorScheme,
      styleNotes: outfit.styleNotes,
      wardrobeSynergy: outfit.wardrobeSynergy,
      occasionFit: outfit.occasionFit,
      tags: outfit.tags || [],
    };
  }

  /**
   * Find product match using multiple strategies
   * Handles cases where Gemini's productId doesn't exactly match our IDs
   */
  private findProductMatch(item: any, products: Product[], slotName: string): Product | undefined {
    const productId = item.productId || '';

    if (!productId || products.length === 0) {
      return undefined;
    }

    // Strategy 1: Exact ID match
    let match = products.find(p => p.id === productId || p.sourceId === productId);
    if (match) {
      this.logger.debug(`Exact match found for "${productId}" in slot "${slotName}"`);
      return match;
    }

    // Strategy 2: Partial ID match (Gemini might truncate IDs)
    match = products.find(p =>
      (p.id && productId.includes(p.id)) ||
      (p.id && p.id.includes(productId)) ||
      (p.sourceId && p.sourceId.includes(productId))
    );
    if (match) {
      this.logger.debug(`Partial match found for "${productId}" in slot "${slotName}"`);
      return match;
    }

    // Strategy 3: Match by index if productId looks like a number (1, 2, 3...)
    const indexMatch = productId.match(/^(\d+)$/);
    if (indexMatch) {
      const idx = parseInt(indexMatch[1], 10) - 1; // Gemini uses 1-based indexing
      if (idx >= 0 && idx < products.length) {
        this.logger.debug(`Index match (${idx + 1}) found in slot "${slotName}"`);
        return products[idx];
      }
    }

    // Strategy 4: Match by product name substring (for longer IDs that might be names)
    if (productId.length > 10) {
      match = products.find(p =>
        (p.title && p.title.toLowerCase().includes(productId.toLowerCase())) ||
        (p.title && productId.toLowerCase().includes(p.title.toLowerCase()))
      );
      if (match) {
        this.logger.debug(`Name match found for "${productId}" in slot "${slotName}"`);
        return match;
      }
    }

    this.logger.debug(`No match found for productId "${productId}" in slot "${slotName}"`);
    return undefined;
  }

  /**
   * Response when insufficient products found
   */
  private buildInsufficientProductsResponse(): AgentResponse {
    return {
      message: "I couldn't find enough products to create complete outfits. Let me show you what I found instead!",
      type: ResponseType.TEXT,
      suggestedActions: [
        {
          label: 'Browse individual items',
          action: 'browse_products',
        },
        {
          label: 'Try different search',
          action: 'new_search',
        },
      ],
    };
  }

  /**
   * Response when no outfits generated
   */
  private buildNoOutfitsResponse(): AgentResponse {
    return {
      message: "I found products but couldn't create outfit combinations. Would you like to see the individual items instead?",
      type: ResponseType.TEXT,
      suggestedActions: [
        {
          label: 'Show products',
          action: 'show_products',
        },
        {
          label: 'Adjust preferences',
          action: 'adjust_preferences',
        },
      ],
    };
  }

  /**
   * Replace item in existing outfit
   */
  async replaceOutfitItem(
    outfitId: string,
    slotToReplace: string,
    userContext?: any,
  ): Promise<Product[]> {
    this.logger.debug(
      `Replacing ${slotToReplace} in outfit ${outfitId}`,
    );

    // This would:
    // 1. Get current outfit
    // 2. Search for alternatives in specified slot
    // 3. Return alternative products

    // Placeholder for now
    return [];
  }
}
