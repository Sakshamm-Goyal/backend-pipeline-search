import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import {
  WeatherContext,
  WeatherCondition,
  WeatherApiResponse,
} from '../dto/context-pack.dto';

/**
 * Weather Service
 *
 * Fetches weather data from OpenWeatherMap API and transforms it
 * into a format suitable for fashion recommendations.
 */
@Injectable()
export class WeatherService {
  private readonly logger = new Logger(WeatherService.name);
  private readonly apiKey: string;
  private readonly baseUrl = 'https://api.openweathermap.org/data/2.5';

  // Cache weather data for 30 minutes
  private cache = new Map<string, { data: WeatherContext; timestamp: number }>();
  private readonly CACHE_TTL = 30 * 60 * 1000; // 30 minutes

  constructor(
    private configService: ConfigService,
    private httpService: HttpService,
  ) {
    this.apiKey = this.configService.get<string>('OPENWEATHER_API_KEY') || '';
    if (!this.apiKey) {
      this.logger.warn('OPENWEATHER_API_KEY not configured - weather features will use defaults');
    }
  }

  /**
   * Get weather for a location
   */
  async getWeather(location?: string): Promise<WeatherContext | undefined> {
    if (!location || !this.apiKey) {
      return undefined;
    }

    // Check cache first
    const cacheKey = location.toLowerCase();
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      this.logger.debug(`Weather cache hit for ${location}`);
      return cached.data;
    }

    try {
      // Get coordinates from location name
      const coords = await this.geocode(location);
      if (!coords) {
        this.logger.warn(`Could not geocode location: ${location}`);
        return this.getDefaultWeather(location);
      }

      // Fetch weather data
      const response = await firstValueFrom(
        this.httpService.get(`${this.baseUrl}/weather`, {
          params: {
            lat: coords.lat,
            lon: coords.lon,
            appid: this.apiKey,
            units: 'imperial', // Fahrenheit
          },
        }),
      );

      const weather = this.transformWeatherResponse(response.data as WeatherApiResponse, location);

      // Cache the result
      this.cache.set(cacheKey, { data: weather, timestamp: Date.now() });

      this.logger.log(`Weather fetched for ${location}: ${weather.temperature}°F, ${weather.condition}`);

      return weather;
    } catch (error) {
      this.logger.error(`Failed to fetch weather for ${location}: ${(error as Error).message}`);
      return this.getDefaultWeather(location);
    }
  }

  /**
   * Geocode a location name to coordinates
   */
  private async geocode(location: string): Promise<{ lat: number; lon: number } | null> {
    try {
      const response = await firstValueFrom(
        this.httpService.get<Array<{ lat: number; lon: number; name: string }>>('https://api.openweathermap.org/geo/1.0/direct', {
          params: {
            q: location,
            limit: 1,
            appid: this.apiKey,
          },
        }),
      );

      const data = response.data;
      if (data && data.length > 0) {
        return {
          lat: data[0].lat,
          lon: data[0].lon,
        };
      }

      return null;
    } catch (error) {
      this.logger.error(`Geocoding failed for ${location}: ${(error as Error).message}`);
      return null;
    }
  }

  /**
   * Transform API response to WeatherContext
   */
  private transformWeatherResponse(data: WeatherApiResponse, location: string): WeatherContext {
    const mainCondition = data.weather[0]?.main.toLowerCase() || '';
    const temp = data.main.temp;

    return {
      temperature: Math.round(temp),
      feelsLike: Math.round(data.main.feels_like),
      condition: this.mapCondition(mainCondition, temp),
      humidity: data.main.humidity,
      windSpeed: Math.round(data.wind.speed),
      precipitation: data.rain?.['1h'] || 0,
      uvIndex: data.uvi || 0,
      location,
      timestamp: new Date(),
    };
  }

  /**
   * Map weather API condition to our WeatherCondition type
   */
  private mapCondition(apiCondition: string, temperature: number): WeatherCondition {
    // Temperature-based conditions take precedence
    if (temperature >= 90) return 'hot';
    if (temperature <= 32) return 'cold';

    // Weather condition mapping
    const conditionMap: Record<string, WeatherCondition> = {
      clear: 'sunny',
      sunny: 'sunny',
      clouds: 'cloudy',
      overcast: 'cloudy',
      'few clouds': 'partly_cloudy',
      'scattered clouds': 'partly_cloudy',
      'broken clouds': 'partly_cloudy',
      rain: 'rainy',
      drizzle: 'rainy',
      shower: 'rainy',
      thunderstorm: 'stormy',
      snow: 'snowy',
      sleet: 'snowy',
      mist: 'foggy',
      fog: 'foggy',
      haze: 'foggy',
      smoke: 'foggy',
      dust: 'windy',
      sand: 'windy',
      squall: 'windy',
      tornado: 'stormy',
    };

    return conditionMap[apiCondition] || 'partly_cloudy';
  }

  /**
   * Get default weather when API is unavailable
   */
  private getDefaultWeather(location: string): WeatherContext {
    // Return mild, pleasant weather as default
    return {
      temperature: 68,
      feelsLike: 68,
      condition: 'partly_cloudy',
      humidity: 50,
      windSpeed: 5,
      precipitation: 0,
      uvIndex: 3,
      location,
      timestamp: new Date(),
    };
  }

  /**
   * Get weather-appropriate greeting
   */
  getWeatherGreeting(weather: WeatherContext): string {
    if (weather.temperature >= 85) {
      return "It's a hot one out there!";
    }
    if (weather.temperature <= 40) {
      return "Bundle up, it's chilly!";
    }
    if (weather.condition === 'rainy') {
      return "Don't forget your umbrella!";
    }
    if (weather.condition === 'sunny') {
      return "Perfect day for an outfit!";
    }
    return "Great weather for fashion!";
  }

  /**
   * Determine if weather data should affect recommendations
   */
  isWeatherSignificant(weather: WeatherContext): boolean {
    return (
      weather.temperature < 50 || // Cold
      weather.temperature > 80 || // Hot
      weather.condition === 'rainy' ||
      weather.condition === 'snowy' ||
      weather.condition === 'stormy' ||
      weather.precipitation > 0.1
    );
  }
}
