import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Anthropic from '@anthropic-ai/sdk';

export interface IntentClassification {
  intent: string;
  confidence: number;
  filters: Record<string, any>;
  reasoning: string;
  clarificationNeeded?: string[];
}

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

@Injectable()
export class ClaudeService {
  private readonly logger = new Logger(ClaudeService.name);
  private client: Anthropic;

  constructor(private config: ConfigService) {
    const apiKey = this.config.get<string>('ANTHROPIC_API_KEY');
    if (!apiKey) {
      throw new Error('ANTHROPIC_API_KEY is required in environment variables');
    }

    this.client = new Anthropic({
      apiKey,
    });

    this.logger.log('Claude service initialized');
  }

  /**
   * Classify user intent using Claude Sonnet 4.5 (recommended)
   * Falls back to Claude Sonnet 4, then Claude Sonnet 3.5 if models are unavailable
   * Uses configurable timeout (default 20 seconds per attempt)
   * 
   * Model IDs from: https://platform.claude.com/docs/en/about-claude/models/overview
   */
  async classifyIntent(
    message: string,
    conversationHistory: Message[],
    userContext: any,
  ): Promise<IntentClassification> {
    const startTime = Date.now();
    // Use specific model versions (not aliases) for production reliability
    // Primary: Claude Sonnet 4.5 (recommended - best balance of intelligence, speed, cost)
    const primaryModel = 'claude-sonnet-4-5-20250929';
    // Fallback 1: Claude Sonnet 4 (legacy)
    const fallbackModel1 = 'claude-sonnet-4-20250514';
    // Fallback 2: Claude Sonnet 3.5 (valid and reliable)
    const fallbackModel2 = 'claude-3-5-sonnet-20241022';
    // Use config timeout or default to 20 seconds (more reasonable than 5s)
    const TIMEOUT_MS = parseInt(
      this.config.get<string>('LLM_TIMEOUT_MS') || '20000',
      10,
    );

    const systemPrompt = this.buildIntentSystemPrompt(userContext);

    // Helper function to create request with timeout
    const createRequestWithTimeout = async (model: string) => {
      return Promise.race([
        this.client.messages.create({
          model,
          max_tokens: 1024,
          system: systemPrompt,
          messages: [
            ...this.formatHistory(conversationHistory),
            { role: 'user', content: message },
          ],
        }),
        new Promise((_, reject) =>
          setTimeout(
            () => reject(new Error(`Request timeout after ${TIMEOUT_MS}ms`)),
            TIMEOUT_MS,
          ),
        ),
      ]) as Promise<any>;
    };

    // Try primary model first
    try {
      const response = await createRequestWithTimeout(primaryModel);

      const firstContent = response.content[0];
      const text = 'text' in firstContent ? firstContent.text : '';
      const result = this.parseIntentResponse(text);

      const duration = Date.now() - startTime;
      this.logger.log(
        `Intent classified: ${result.intent} (confidence: ${result.confidence}) in ${duration}ms`
      );

      return result;
    } catch (error: any) {
      // Check if it's a model unavailability error, timeout, or not found
      const isModelError = 
        error?.error?.error?.type === 'api_error' ||
        error?.error?.error?.type === 'not_found_error' ||
        error?.status === 500 ||
        error?.status === 404 ||
        error?.message?.includes('timeout') ||
        (error?.message?.toLowerCase().includes('unavailable') ||
         error?.error?.error?.message?.toLowerCase().includes('unavailable') ||
         error?.error?.error?.message?.toLowerCase().includes('not found'));

      if (isModelError) {
        // Try first fallback model
        try {
          this.logger.warn(
            `Primary model ${primaryModel} failed (${error?.error?.error?.message || error?.message || 'timeout'}), trying fallback: ${fallbackModel1}`
          );

          const response = await createRequestWithTimeout(fallbackModel1);

          const firstContent = response.content[0];
          const text = 'text' in firstContent ? firstContent.text : '';
          const result = this.parseIntentResponse(text);

          const duration = Date.now() - startTime;
          this.logger.log(
            `Intent classified (fallback 1): ${result.intent} (confidence: ${result.confidence}) in ${duration}ms`
          );

          return result;
        } catch (fallback1Error: any) {
          // Try second fallback model
          try {
            this.logger.warn(
              `Fallback model 1 ${fallbackModel1} failed, trying fallback 2: ${fallbackModel2}`
            );

            const response = await createRequestWithTimeout(fallbackModel2);

            const firstContent = response.content[0];
            const text = 'text' in firstContent ? firstContent.text : '';
            const result = this.parseIntentResponse(text);

            const duration = Date.now() - startTime;
            this.logger.log(
              `Intent classified (fallback 2): ${result.intent} (confidence: ${result.confidence}) in ${duration}ms`
            );

            return result;
          } catch (fallback2Error: any) {
            this.logger.error(
              `All Claude models failed. Primary: ${primaryModel}, Fallback 1: ${fallbackModel1}, Fallback 2: ${fallbackModel2}`,
              { primaryError: error, fallback1Error, fallback2Error }
            );
            throw fallback2Error;
          }
        }
      }

      // If it's not a model error, throw the original error
      this.logger.error('Intent classification failed', error);
      throw error;
    }
  }

  /**
   * Generate a natural clarification question when intent is unclear
   */
  async generateClarification(
    message: string,
    missingFields: string[],
    userContext: any,
  ): Promise<string> {
    const systemPrompt = `You are Elara, a friendly and helpful fashion assistant.

The user's message is unclear or missing important information. Generate a natural, conversational question to clarify what they need.

Missing information: ${missingFields.join(', ')}

IMPORTANT:
- Don't ask for information we already have from the user profile
- Keep it brief and conversational
- Make it feel natural, not robotic
- Focus on the most critical missing piece

USER PROFILE (what we already know):
- Gender: ${userContext.profile?.gender || 'not specified'}
- Style: ${userContext.profile?.primaryStyle || 'not specified'}
- Budget: ${userContext.profile?.priceRange ? `$${userContext.profile.priceRange.min}-${userContext.profile.priceRange.max}` : 'not specified'}`;

    // Use same model configuration as classifyIntent for consistency
    const models = [
      'claude-sonnet-4-5-20250929', // Primary: Claude Sonnet 4.5
      'claude-sonnet-4-20250514',    // Fallback 1: Claude Sonnet 4
      'claude-3-5-sonnet-20241022',  // Fallback 2: Claude Sonnet 3.5
    ];
    const TIMEOUT_MS = parseInt(
      this.config.get<string>('LLM_TIMEOUT_MS') || '20000',
      10,
    );

    // Helper function to create request with timeout
    const createRequestWithTimeout = async (model: string) => {
      return Promise.race([
        this.client.messages.create({
          model,
          max_tokens: 256,
          system: systemPrompt,
          messages: [{ role: 'user', content: message }],
        }),
        new Promise((_, reject) =>
          setTimeout(
            () => reject(new Error(`Request timeout after ${TIMEOUT_MS}ms`)),
            TIMEOUT_MS,
          ),
        ),
      ]) as Promise<any>;
    };

    for (const model of models) {
      try {
        const response = await createRequestWithTimeout(model);

        const firstContent = response.content[0];
        return 'text' in firstContent ? firstContent.text : '';
      } catch (error: any) {
        // If it's the last model, log and return fallback
        if (model === models[models.length - 1]) {
          this.logger.error('Clarification generation failed for all models', error);
          return 'Could you tell me a bit more about what you\'re looking for?';
        }
        // Otherwise, try next model
        this.logger.warn(`Clarification model ${model} failed (${error?.error?.error?.message || error?.message || 'timeout'}), trying next fallback`);
      }
    }

    // Should never reach here, but just in case
    return 'Could you tell me a bit more about what you\'re looking for?';
  }

  private buildIntentSystemPrompt(userContext: any): string {
    const profile = userContext?.profile || {};

    return `You are an intent classifier for Elara, an AI-powered fashion assistant that ONLY helps with fashion, clothing, and style.

USER PROFILE:
- Gender: ${profile.gender || 'not specified'}
- Primary Style: ${profile.primaryStyle || 'not specified'}
- Style Influences: ${profile.selectedStyles?.join(', ') || 'none'}
- Budget Range: $${profile.priceRange?.min || 0}-${profile.priceRange?.max || 'unlimited'}
- Location: ${profile.location?.city || 'not specified'}
- Body Type: ${profile.bodyType || 'not specified'}
- Size: ${profile.size || 'not specified'}

═══════════════════════════════════════════════════════════════════════════════
STEP 1: DOMAIN CHECK (CRITICAL - DO THIS FIRST)
═══════════════════════════════════════════════════════════════════════════════

Before classifying intent, check if the message is about FASHION/CLOTHING/STYLE:

OFF-TOPIC (classify as general_chat with confidence 0.95):
- Technology, AI, APIs, programming, software (e.g., "Google AI Gemini model", "API keys")
- Food, cooking, recipes
- Travel destinations, hotels
- News, politics, current events
- Health, fitness (unless asking about workout clothes)
- Finance, investing, cryptocurrency
- Entertainment (movies, music, games)
- Science, math, physics
- Any topic NOT related to fashion, clothing, accessories, or personal style

If OFF-TOPIC: Return general_chat with reasoning: "Off-topic: [topic]. Elara only assists with fashion."

═══════════════════════════════════════════════════════════════════════════════
STEP 2: CLASSIFY FASHION-RELATED INTENTS
═══════════════════════════════════════════════════════════════════════════════

Only if the message IS about fashion, classify into ONE of these intents:

1. **general_chat**: Greetings, thanks, or off-topic messages
   Examples: "Hi!", "Hello", "Thanks!", "Bye", "Good morning"
   Also use for: Off-topic questions (tech, food, news, etc.)

2. **fashion_advice**: Asking for GENERAL styling tips WITHOUT wanting to browse products

   STRONG INDICATORS (use fashion_advice):
   - "in general" / "generally" / "typically" / "usually"
   - "what looks good WITH [item]" (asking for advice, not products)
   - "what colors go with" / "what matches" (color theory)
   - "how should I style" / "styling tips" / "what pairs well"
   - "what type of" / "what kind of" (seeking advice)
   - Questions about fashion rules, dos and don'ts

   Examples:
   - "In general, what looks good under red pants?" → fashion_advice
   - "What colors go well with navy blue?" → fashion_advice
   - "How should I style a leather jacket?" → fashion_advice
   - "What type of shoes work with wide-leg pants?" → fashion_advice
   - "What looks good with red pants?" → fashion_advice (no action verb like "show me")

3. **product_search**: User wants to SEE/BROWSE/BUY a SINGLE TYPE of product (no occasion)

   REQUIRED INDICATORS (must have at least one):
   - "show me" / "find me" / "search for" / "look up"
   - "I need" / "I want" / "I'm looking for" / "I want to buy"
   - "can you find" / "get me" / "send me links"
   - Direct item requests with clear shopping intent
   - NO occasion/event mentioned

   Examples:
   - "Show me blue jeans" → product_search
   - "Find me red shirts" → product_search
   - "I want Nike sneakers" → product_search

4. **outfit_request**: Wants COMPLETE outfit OR mentions an OCCASION/EVENT
   IMPORTANT: This is the intent when user wants a COMPLETE LOOK or mentions ANY occasion!

   KEY INDICATORS (use outfit_request if ANY of these):
   - Mentions occasion: wedding, date, interview, party, work, gym, cocktail, event, dinner, brunch, casual outing
   - Asks for "outfit", "complete look", "what to wear", "what should I wear"
   - Asks for dress/formal wear for an event (e.g., "cocktail dress for event" = outfit_request!)
   - Mentions body type considerations ("plus-size", "flattering")
   - Asks for recommendations with multiple criteria (occasion + style + budget)

   Examples:
   - "What should I wear to a wedding?" → outfit_request
   - "Outfit for date night" → outfit_request
   - "I'm looking for a cocktail dress for an event" → outfit_request (HAS EVENT!)
   - "I need something flattering for a party" → outfit_request
   - "Looking for plus-size dress for dinner" → outfit_request
   - "Help me find something to wear to work" → outfit_request

5. **single_item_search**: Searching for ONE specific item WITH brand/specs (no occasion)
   Examples: "Show me Nike Air Max", "I want a leather jacket under $200"

6. **item_replacement**: Replace an item in a previously shown outfit
   Key: References "outfit 1/2/3" or "the top/shoes in that outfit"
   Examples: "Can I get a different top for outfit 2?", "Show me other shoe options"

7. **feedback**: Like/dislike on recommendations
   Examples: "I like option 1", "Not a fan of this", "Love it!"

8. **clarification_needed**: ONLY when truly ambiguous AND confidence < 0.7

═══════════════════════════════════════════════════════════════════════════════
CRITICAL DECISION RULES
═══════════════════════════════════════════════════════════════════════════════

product_search vs outfit_request - THE KEY DIFFERENCE:

| Query | Intent | Why |
|-------|--------|-----|
| "Show me red shirts" | product_search | Simple product, no occasion |
| "Red dress for party" | outfit_request | HAS OCCASION (party) |
| "I need jeans" | product_search | Simple product, no occasion |
| "I need outfit for interview" | outfit_request | HAS OCCASION (interview) |
| "Find cocktail dress" | product_search | Just a product type |
| "Cocktail dress for event" | outfit_request | HAS OCCASION (event)! |
| "Plus-size dress that's flattering" | outfit_request | Body considerations = wants complete look |
| "Show me Nike shoes" | product_search | Brand + product, no occasion |

CONFIDENCE GUIDELINES:
- Off-topic messages: 0.95 confidence for general_chat
- Has occasion/event mentioned: 0.95+ confidence for outfit_request
- Clear fashion_advice (has indicators): 0.9+ confidence
- Clear product_search (no occasion): 0.9+ confidence
- Ambiguous: 0.6-0.8 confidence

EXTRACTION RULES (CRITICAL - extract ALL mentioned attributes):
- **occasion**: casual, formal, business, party, date, workout, travel, cocktail, dinner, wedding, interview, brunch
- **itemType**: specific clothing type (dress, shirt, pants, shoes, etc.) - ALWAYS extract if mentioned
- **color**: any colors mentioned
- **brand**: specific brands mentioned
- **priceRange**: budget if mentioned (e.g., "$150" → max: 150, "under $200" → max: 200)
- **style**: style descriptors (minimal, edgy, bohemian, flattering, etc.)
- **size**: any size mentioned (US 20, plus-size, XL, etc.)
- **features**: specific features requested (sleeves, v-neck, high-waist, etc.)
- **gender**: infer from context if not explicit (cocktail dress → female)

RESPONSE FORMAT (JSON):
{
  "intent": "string (one of the 8 intents)",
  "confidence": 0.0-1.0,
  "filters": {
    "occasion": "string or null",
    "itemType": "string or null (e.g., 'cocktail dress', 'shirt', 'jeans')",
    "color": ["array of color strings"],
    "brand": ["array of brand strings"],
    "priceRange": { "min": number, "max": number } or null,
    "style": "string or null",
    "size": "string or null (e.g., 'US 20', 'plus-size', 'XL')",
    "features": ["array of feature strings (e.g., 'sleeves', 'flattering')"],
    "gender": "male" | "female" | "unisex" | null
  },
  "reasoning": "brief 1-sentence explanation",
  "clarificationNeeded": ["field1", "field2"] // only if confidence < 0.7
}`;
  }

  private formatHistory(history: Message[]): any[] {
    // Take last 5 messages for context
    return history.slice(-5).map(msg => ({
      role: msg.role === 'assistant' ? 'assistant' : 'user',
      content: msg.content,
    }));
  }

  private parseIntentResponse(text: string): IntentClassification {
    try {
      // Try to extract JSON from markdown code blocks
      let jsonText = text;

      // Check for markdown code block
      const codeBlockMatch = text.match(/```json\s*\n([\s\S]*?)\n```/);
      if (codeBlockMatch) {
        jsonText = codeBlockMatch[1];
      } else {
        // Try to find JSON object
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          jsonText = jsonMatch[0];
        }
      }

      const parsed = JSON.parse(jsonText);

      return {
        intent: parsed.intent,
        confidence: parsed.confidence,
        filters: parsed.filters || {},
        reasoning: parsed.reasoning,
        clarificationNeeded: parsed.clarificationNeeded,
      };
    } catch (error) {
      this.logger.error('Failed to parse intent response', error);
      this.logger.debug('Raw response:', text);

      // Fallback to general_chat with low confidence
      return {
        intent: 'general_chat',
        confidence: 0.5,
        filters: {},
        reasoning: 'Failed to parse response, defaulting to chat',
      };
    }
  }
}
