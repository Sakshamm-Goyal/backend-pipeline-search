import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { GoogleGenerativeAI } from '@google/generative-ai';

export interface OutfitRecommendation {
  name: string;
  style: string;
  items: Array<{
    slot: string;
    productId: string;
    selectionReason: string;
  }>;
  totalPrice: number;
  colorScheme: string;
  styleNotes: string;
  wardrobeSynergy: string;
  occasionFit: string;
}

export interface RankedProduct {
  product: any;
  originalRank: number;
  newRank: number;
  reasoning: string;
}

@Injectable()
export class GeminiService {
  private readonly logger = new Logger(GeminiService.name);
  private genAI: GoogleGenerativeAI;
  private model: any;
  private chatModel: any;

  constructor(private config: ConfigService) {
    const apiKey = this.config.get<string>('GOOGLE_AI_API_KEY');
    if (!apiKey) {
      throw new Error('GOOGLE_AI_API_KEY is required in environment variables');
    }

    this.genAI = new GoogleGenerativeAI(apiKey);

    // Model for JSON responses (outfits, rankings)
    this.model = this.genAI.getGenerativeModel({
      model: 'gemini-3-pro-preview',
      generationConfig: {
        temperature: 0.7, // Some creativity for outfit combinations
        maxOutputTokens: 8192, // Increased from 4096 to handle full outfit responses
        responseMimeType: 'application/json',
      },
    });

    // Model for text chat responses
    this.chatModel = this.genAI.getGenerativeModel({
      model: 'gemini-3-pro-preview',
      generationConfig: {
        temperature: 0.8, // More creative for conversational responses
        maxOutputTokens: 1024,
      },
    });

    this.logger.log('Gemini 3 Pro service initialized');
  } 

  /**
   * Generate 3 personalized outfit recommendations
   */
  async generateOutfitRecommendations(
    userQuery: string,
    userContext: any,
    slotProducts: Map<string, any[]>,
    filters: any,
  ): Promise<OutfitRecommendation[]> {
    const startTime = Date.now();

    try {
      const prompt = this.buildOutfitPrompt(userQuery, userContext, slotProducts, filters);

      // Log available products for debugging
      this.logger.debug(`Generating outfits for query: "${userQuery}"`);
      this.logger.debug(`Available slots: ${Array.from(slotProducts.keys()).join(', ')}`);
      slotProducts.forEach((products, slot) => {
        this.logger.debug(`  ${slot}: ${products.length} products`);
      });

      const result = await this.model.generateContent(prompt);
      const response = result.response.text();

      // Log raw response for debugging
      if (!response || response.trim() === '') {
        this.logger.warn('Gemini 3 Pro returned empty response, checking for safety/block reasons');

        // Check for blocked content or other issues
        const candidates = result.response.candidates;
        if (candidates && candidates.length > 0) {
          const candidate = candidates[0];
          if (candidate.finishReason) {
            this.logger.warn(`Finish reason: ${candidate.finishReason}`);
          }
          if (candidate.safetyRatings) {
            this.logger.warn(`Safety ratings: ${JSON.stringify(candidate.safetyRatings)}`);
          }
        }

        // Try fallback model
        this.logger.log('Trying fallback model due to empty response...');
        return this.generateOutfitsWithFallback(userQuery, userContext, slotProducts, filters);
      }

      this.logger.debug(`Gemini response length: ${response.length} chars`);

      const outfits = this.parseOutfitResponse(response);

      const duration = Date.now() - startTime;
      this.logger.log(
        `Generated ${outfits.length} outfit recommendations in ${duration}ms`
      );

      return outfits;
    } catch (error: any) {
      this.logger.error(`Outfit generation failed: ${error.message}`);
      this.logger.error(error.stack);

      // Check if it's a model availability issue
      if (error.message?.includes('not found') || error.message?.includes('404')) {
        this.logger.warn('Model may not be available, trying fallback model...');
        return this.generateOutfitsWithFallback(userQuery, userContext, slotProducts, filters);
      }

      throw error;
    }
  }

  /**
   * Fallback outfit generation using gemini-2.0-flash-exp
   */
  private async generateOutfitsWithFallback(
    userQuery: string,
    userContext: any,
    slotProducts: Map<string, any[]>,
    filters: any,
  ): Promise<OutfitRecommendation[]> {
    this.logger.log('Attempting fallback with gemini-2.0-flash-exp...');

    try {
      const fallbackModel = this.genAI.getGenerativeModel({
        model: 'gemini-2.0-flash-exp',
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 8192,
          responseMimeType: 'application/json',
        },
      });

      const prompt = this.buildOutfitPrompt(userQuery, userContext, slotProducts, filters);
      const result = await fallbackModel.generateContent(prompt);
      const response = result.response.text();

      if (!response || response.trim() === '') {
        this.logger.warn('Fallback model also returned empty response');
        return [];
      }

      this.logger.log(`Fallback model returned ${response.length} chars`);
      return this.parseOutfitResponse(response);
    } catch (fallbackError) {
      this.logger.error('Fallback outfit generation also failed', fallbackError);
      return [];
    }
  }

  /**
   * Check if we have enough products to generate outfits
   */
  private validateSlotProducts(slotProducts: Map<string, any[]>): boolean {
    const totalProducts = Array.from(slotProducts.values()).reduce(
      (sum, products) => sum + products.length,
      0
    );

    if (totalProducts < 3) {
      this.logger.warn(`Not enough products to generate outfits: ${totalProducts} total`);
      return false;
    }

    return true;
  }

  /**
   * Rerank products using LLM when scores are too close
   */
  async rerankProducts(
    products: any[],
    userPreferences: any,
    context: string,
  ): Promise<RankedProduct[]> {
    if (products.length === 0) return [];

    try {
      const prompt = this.buildRerankPrompt(products, userPreferences, context);

      const result = await this.model.generateContent(prompt);
      const response = JSON.parse(result.response.text());

      // Apply new ranking
      const reranked: RankedProduct[] = response.ranking
        .map((newIdx: number, position: number) => {
          const product = products[newIdx - 1];
          if (!product) return null;

          return {
            product,
            originalRank: newIdx,
            newRank: position + 1,
            reasoning: response.reasoning,
          };
        })
        .filter(Boolean);

      this.logger.log(`Reranked ${reranked.length} products`);
      return reranked;
    } catch (error) {
      this.logger.warn('Product reranking failed, returning original order', error);

      // Return original order with metadata
      return products.map((product, index) => ({
        product,
        originalRank: index + 1,
        newRank: index + 1,
        reasoning: 'Reranking failed, using original order',
      }));
    }
  }

  private buildOutfitPrompt(
    userQuery: string,
    context: any,
    slotProducts: Map<string, any[]>,
    filters: any,
  ): string {
    const profile = context.profile || {};

    return `You are an expert personal stylist creating outfit combinations for Elara, an AI fashion assistant.

USER PROFILE:
- Gender: ${profile.gender || 'not specified'}
- Primary Style: ${profile.primaryStyle || 'versatile'}
- Style Influences: ${profile.selectedStyles?.join(', ') || 'open to all styles'}
- Liked Brands: ${profile.likedBrands?.join(', ') || 'open to all brands'}
- Color Preferences: ${profile.colorPreferences?.join(', ') || 'no specific preference'}
- Colors to Avoid: ${profile.avoidColors?.join(', ') || 'none'}
- Budget Range: $${profile.priceRange?.min || 0} - $${profile.priceRange?.max || 'unlimited'}
- Modest Dressing: ${profile.modestDressing ? 'Yes - prefers more coverage' : 'No specific requirement'}

USER'S WARDROBE CONTEXT:
- Dominant Colors in Wardrobe: ${context.wardrobeColors?.join(', ') || 'unknown'}
- Compatible Existing Pieces: ${this.formatCompatiblePieces(context.compatiblePieces)}

REQUEST DETAILS:
- Occasion: ${filters.occasion || 'everyday casual'}
- Specific Request: "${userQuery}"
${filters.color?.length ? `- Requested Colors: ${filters.color.join(', ')}` : ''}
${filters.style ? `- Requested Style: ${filters.style}` : ''}

AVAILABLE PRODUCTS BY CLOTHING SLOT:
${this.formatSlotProducts(slotProducts)}

YOUR TASK:
Create exactly 3 distinct outfit combinations. For each outfit:

1. SELECT exactly ONE product from each slot
2. ENSURE excellent color harmony (complementary, monochromatic, analogous, or neutral schemes)
3. MATCH the user's style preferences and lifestyle
4. STAY within budget (calculate total price)
5. EXPLAIN how new items work with existing wardrobe pieces
6. VALIDATE that the outfit suits the requested occasion

CRITICAL REQUIREMENTS:
✓ Don't mix inappropriate formality levels (e.g., formal blazer with gym shorts)
✓ Respect modest dressing requirements if specified
✓ Prioritize liked brands when available
✓ Ensure colors actually complement each other (not just random)
✓ Verify total price is within budget
✓ Each outfit must be distinctly different in style/vibe

RESPOND IN THIS EXACT JSON FORMAT:
{
  "outfits": [
    {
      "name": "Descriptive outfit name that captures the vibe",
      "style": "casual|formal|business|party|date|workout|etc",
      "items": [
        {
          "slot": "top",
          "productId": "EXACT_ID_FROM_PRODUCT_LIST",
          "selectionReason": "Why this specific item works in this outfit"
        }
        // ... one item per slot
      ],
      "totalPrice": 0.00,
      "colorScheme": "monochromatic|complementary|analogous|neutral|accent",
      "styleNotes": "Overall styling advice and how to wear this outfit",
      "wardrobeSynergy": "How these new items complement user's existing wardrobe",
      "occasionFit": "Why this outfit is perfect for the specified occasion"
    }
    // ... 2 more distinct outfits
  ]
}`;
  }

  private buildRerankPrompt(
    products: any[],
    preferences: any,
    context: string,
  ): string {
    return `You are a fashion expert. Rerank these ${products.length} products for best fit with user preferences.

USER PREFERENCES:
${JSON.stringify(preferences, null, 2)}

CONTEXT: ${context}

PRODUCTS TO RANK:
${products.map((p, i) => `${i + 1}. ${p.title} - $${p.price} (${p.brand || 'Unknown brand'}) [${p.color || 'No color specified'}]`).join('\n')}

TASK: Reorder these products from best to worst fit for this user.

Consider:
- Style match with user preferences
- Brand fit (liked vs neutral vs disliked)
- Color harmony with existing wardrobe
- Price value within budget
- Quality signals (brand reputation, reviews if available)

Respond in JSON:
{
  "ranking": [3, 1, 5, 2, 4, ...],
  "reasoning": "Brief explanation of why top items rank highest"
}

The "ranking" array should contain the numbers 1-${products.length} in your new preferred order.`;
  }

  private formatSlotProducts(slotProducts: Map<string, any[]>): string {
    const lines: string[] = [];

    slotProducts.forEach((products, slot) => {
      lines.push(`\n${slot.toUpperCase().replace(/_/g, ' ')}:`);

      const limitedProducts = products.slice(0, 10); // Show top 10 per slot
      limitedProducts.forEach((p, i) => {
        lines.push(
          `  ${i + 1}. [ID: ${p.id || p._id}] ${p.title} - $${p.price} (${p.brand || 'Unknown'}) [Color: ${p.color || 'N/A'}]`
        );
      });

      if (products.length > 10) {
        lines.push(`  ... and ${products.length - 10} more options`);
      }
    });

    return lines.join('\n');
  }

  private formatCompatiblePieces(pieces: any[]): string {
    if (!pieces || pieces.length === 0) {
      return 'No specific pieces selected';
    }

    return pieces
      .slice(0, 5) // Show up to 5 pieces
      .map(p => `${p.category}: ${p.name} (${p.color || 'no color specified'})`)
      .join(', ');
  }

  private parseOutfitResponse(text: string): OutfitRecommendation[] {
    try {
      const parsed = JSON.parse(text);

      if (!parsed.outfits || !Array.isArray(parsed.outfits)) {
        this.logger.warn('Invalid outfit response structure');
        return [];
      }

      return parsed.outfits;
    } catch (error) {
      this.logger.error('Failed to parse outfit response', error);
      this.logger.debug('Raw response:', text);
      return [];
    }
  }

  /**
   * Generate a conversational chat response for fashion questions
   */
  async generateChatResponse(
    message: string,
    conversationHistory: Array<{ role: string; content: string }>,
    userContext?: any,
  ): Promise<string> {
    const startTime = Date.now();

    try {
      const profile = userContext?.profile || {};

      const systemPrompt = `You are Elara, a friendly, knowledgeable, and stylish AI fashion assistant. You have expertise in fashion, styling, color theory, and personal style.

USER PROFILE:
- Gender: ${profile.gender || 'not specified'}
- Primary Style: ${profile.primaryStyle || 'versatile'}
- Style Influences: ${profile.selectedStyles?.join(', ') || 'open to all styles'}
- Budget Range: $${profile.priceRange?.min || 0} - $${profile.priceRange?.max || 'unlimited'}

GUIDELINES:
- Be warm, helpful, and enthusiastic about fashion
- Give specific, actionable advice when asked fashion questions
- Use your knowledge of color theory, body types, and current trends
- Keep responses concise but informative (2-4 sentences for simple questions)
- If someone asks about styling or matching items, give concrete suggestions
- Mention that you can search for products or create outfits if relevant
- Never be condescending - assume the user wants genuine help

IMPORTANT: You're having a conversation. Be natural and personable, not robotic.`;

      // Format conversation history for Gemini
      const formattedHistory = conversationHistory.slice(-6).map(msg => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }],
      }));

      // Format system instruction as Content object for newer Gemini models
      const systemInstruction = {
        parts: [{ text: systemPrompt }],
      };

      const chat = this.chatModel.startChat({
        history: formattedHistory,
        systemInstruction: systemInstruction,
      });

      const result = await chat.sendMessage(message);
      const response = result.response.text();

      const duration = Date.now() - startTime;
      this.logger.log(`Generated chat response in ${duration}ms`);

      return response;
    } catch (error) {
      this.logger.error('Chat response generation failed', error);
      // Return a helpful fallback
      return "I'd love to help you with your fashion question! Could you tell me a bit more about what you're looking for? I can search for products, suggest outfits, or give styling advice.";
    }
  }
}
