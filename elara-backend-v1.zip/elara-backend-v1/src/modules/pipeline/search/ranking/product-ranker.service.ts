import { Injectable, Logger, Optional } from '@nestjs/common';
import { Product } from '../dto/product.dto';
import { SearchQuery } from '../dto/search-query.dto';
import { GeminiService } from '../../infrastructure/llm/gemini.service';
import { PersonalizationService, UserProfile } from '../../personalization/personalization.service';

/**
 * Product Ranker Service
 *
 * Ranks and scores products based on multiple signals:
 * - Text relevance (title/description match)
 * - User preferences (style, brand, price)
 * - Product quality signals (ratings, reviews)
 * - Price attractiveness (value for money)
 * - Source reliability
 * - Personalization signals (behavioral data from PersonalizationService)
 *
 * Uses a weighted scoring system, with optional LLM reranking
 * for close scores (when differences < 5 points).
 *
 * When PersonalizationService is available, uses behavioral
 * data to boost scores for preferred categories, brands, etc.
 */
@Injectable()
export class ProductRankerService {
  private readonly logger = new Logger(ProductRankerService.name);

  constructor(
    private geminiService: GeminiService,
    @Optional() private personalizationService?: PersonalizationService,
  ) {}

  /**
   * Rank products by relevance and user preferences
   */
  async rankProducts(
    products: Product[],
    query: SearchQuery,
    userContext?: any,
  ): Promise<Product[]> {
    if (products.length === 0) return [];

    const startTime = Date.now();

    // Step 0: Try personalization-based reranking first if available
    if (this.personalizationService && userContext?.userId) {
      try {
        const personalizedProducts = await this.personalizationService.rerankProducts(
          products,
          userContext.userId,
          userContext.profile as UserProfile,
          query.terms,
          userContext.occasion,
          query.minPrice || query.maxPrice
            ? { min: query.minPrice, max: query.maxPrice }
            : undefined,
        );

        const duration = Date.now() - startTime;
        this.logger.log(
          `Ranked ${personalizedProducts.length} products (personalized) in ${duration}ms`,
        );

        return personalizedProducts;
      } catch (error) {
        this.logger.warn(
          `Personalization reranking failed, falling back to ML: ${(error as Error).message}`,
        );
        // Fall through to standard ranking
      }
    }

    // Step 1: Score each product
    const scoredProducts = products.map((product) => ({
      product,
      score: this.calculateScore(product, query, userContext),
    }));

    // Step 2: Sort by score (descending)
    scoredProducts.sort((a, b) => b.score - a.score);

    // Step 3: Check if top products are too close (< 5 points difference)
    const shouldLlmRerank = this.shouldUseLlmReranking(scoredProducts);

    if (shouldLlmRerank) {
      this.logger.debug('Top products too close, using LLM reranking');

      try {
        // LLM rerank top 20 products
        const topProducts = scoredProducts.slice(0, 20).map((sp) => sp.product);
        const reranked = await this.geminiService.rerankProducts(
          topProducts,
          userContext?.profile || {},
          query.terms,
        );

        // Combine: LLM-reranked top 20 + remaining products
        const rankedProducts = reranked.map((r) => r.product);
        const remainingProducts = scoredProducts
          .slice(20)
          .map((sp) => sp.product);

        const allProducts = [...rankedProducts, ...remainingProducts];

        // Add scores
        allProducts.forEach((p, i) => {
          p.score = 100 - i; // Descending score
        });

        const duration = Date.now() - startTime;
        this.logger.log(
          `Ranked ${allProducts.length} products (with LLM) in ${duration}ms`,
        );

        return allProducts;
      } catch (error) {
        this.logger.warn(`LLM reranking failed, using ML scores: ${(error as Error).message}`);
        // Fall through to ML-only ranking
      }
    }

    // Add scores to products
    const rankedProducts = scoredProducts.map((sp) => {
      sp.product.score = Math.round(sp.score);
      return sp.product;
    });

    const duration = Date.now() - startTime;
    this.logger.log(
      `Ranked ${rankedProducts.length} products (ML only) in ${duration}ms`,
    );

    return rankedProducts;
  }

  /**
   * Calculate relevance score for a product (0-100)
   */
  private calculateScore(
    product: Product,
    query: SearchQuery,
    userContext?: any,
  ): number {
    let score = 0;

    // 1. Text Relevance (0-30 points)
    score += this.scoreTextRelevance(product, query);

    // 2. Brand Match (0-15 points)
    score += this.scoreBrandMatch(product, query, userContext);

    // 3. Price Fit (0-20 points)
    score += this.scorePriceFit(product, query, userContext);

    // 4. Quality Signals (0-15 points)
    score += this.scoreQuality(product);

    // 5. Style Match (0-10 points)
    score += this.scoreStyleMatch(product, query, userContext);

    // 6. Source Reliability (0-10 points)
    score += this.scoreSourceReliability(product);

    return Math.min(score, 100); // Cap at 100
  }

  /**
   * Score text relevance (title/description match)
   */
  private scoreTextRelevance(product: Product, query: SearchQuery): number {
    let score = 0;
    const queryTerms = query.terms.toLowerCase().split(/\s+/);
    const title = product.title.toLowerCase();
    const description = product.description?.toLowerCase() || '';

    // Check how many query terms appear in title
    const titleMatches = queryTerms.filter((term) => title.includes(term)).length;
    score += (titleMatches / queryTerms.length) * 20; // Max 20 points

    // Bonus for exact phrase match
    if (title.includes(query.terms.toLowerCase())) {
      score += 5;
    }

    // Description matches (less weight)
    const descMatches = queryTerms.filter((term) =>
      description.includes(term),
    ).length;
    score += (descMatches / queryTerms.length) * 5; // Max 5 points

    return score;
  }

  /**
   * Score brand match
   */
  private scoreBrandMatch(
    product: Product,
    query: SearchQuery,
    userContext?: any,
  ): number {
    let score = 0;

    const productBrand = product.brand?.toLowerCase();
    if (!productBrand) return 0;

    // Query specifies brand
    if (query.brands?.length) {
      const matchesBrand = query.brands.some(
        (b) => b.toLowerCase() === productBrand,
      );
      score += matchesBrand ? 15 : 0; // Full points for exact match
    } else if (userContext?.profile?.likedBrands?.length) {
      // User has liked brands
      const matchesLikedBrand = userContext.profile.likedBrands.some(
        (b: string) => b.toLowerCase() === productBrand,
      );
      score += matchesLikedBrand ? 10 : 0;

      // Penalty for disliked brands
      const matchesDislikedBrand = userContext.profile?.dislikedBrands?.some(
        (b: string) => b.toLowerCase() === productBrand,
      );
      if (matchesDislikedBrand) score -= 10;
    }

    return Math.max(score, 0);
  }

  /**
   * Score price fit (within budget, good value)
   */
  private scorePriceFit(
    product: Product,
    query: SearchQuery,
    userContext?: any,
  ): number {
    let score = 0;

    const minPrice = query.minPrice || userContext?.profile?.priceRange?.min || 0;
    const maxPrice =
      query.maxPrice || userContext?.profile?.priceRange?.max || 10000;

    // Within budget
    if (product.price >= minPrice && product.price <= maxPrice) {
      score += 15; // Within range: 15 points
    } else if (product.price < minPrice) {
      // Below budget (might be lower quality)
      score += 10;
    } else {
      // Above budget (penalty)
      const overage = (product.price - maxPrice) / maxPrice;
      score += Math.max(0, 10 - overage * 20); // Decrease with overage
    }

    // Bonus for good deals (on sale)
    if (product.onSale && product.discount) {
      score += Math.min(product.discount / 10, 5); // Up to 5 bonus points
    }

    return score;
  }

  /**
   * Score product quality signals
   */
  private scoreQuality(product: Product): number {
    let score = 0;

    // Rating (0-5 stars → 0-10 points)
    if (product.rating) {
      score += (product.rating / 5) * 10;
    }

    // Review count (more reviews = more reliable)
    if (product.reviewCount) {
      if (product.reviewCount >= 100) score += 5;
      else if (product.reviewCount >= 50) score += 3;
      else if (product.reviewCount >= 10) score += 1;
    }

    return score;
  }

  /**
   * Score style match
   */
  private scoreStyleMatch(
    product: Product,
    query: SearchQuery,
    userContext?: any,
  ): number {
    let score = 0;

    // Query specifies style
    if (query.style) {
      const styleLower = query.style.toLowerCase();
      const title = product.title.toLowerCase();
      const tags = product.tags?.map((t) => t.toLowerCase()) || [];

      if (title.includes(styleLower) || tags.includes(styleLower)) {
        score += 5;
      }
    }

    // User profile styles
    if (userContext?.profile?.selectedStyles?.length) {
      const userStyles = userContext.profile.selectedStyles.map((s: string) =>
        s.toLowerCase(),
      );
      const title = product.title.toLowerCase();
      const tags = product.tags?.map((t) => t.toLowerCase()) || [];

      const matchesUserStyle = userStyles.some(
        (style: string) => title.includes(style) || tags.includes(style),
      );

      if (matchesUserStyle) score += 5;
    }

    return score;
  }

  /**
   * Score source reliability
   */
  private scoreSourceReliability(product: Product): number {
    // Prioritize certain sources
    const sourceScores: Record<string, number> = {
      shopstyle: 10, // Verified API data
      oxylabs: 8, // Google Shopping data
      asos_scraper: 6, // Well-known retailer
      zara_scraper: 6,
      hm_scraper: 6,
      cache: 5, // Cached (might be stale)
    };

    return sourceScores[product.source] || 5;
  }

  /**
   * Check if top products are too close for ML ranking
   * Use LLM if top 5 products have < 5 point difference
   */
  private shouldUseLlmReranking(
    scoredProducts: Array<{ product: Product; score: number }>,
  ): boolean {
    if (scoredProducts.length < 5) return false;

    const top5 = scoredProducts.slice(0, 5);
    const scores = top5.map((sp) => sp.score);

    const maxScore = Math.max(...scores);
    const minScore = Math.min(...scores);

    const difference = maxScore - minScore;

    return difference < 5; // Close scores → use LLM
  }

  /**
   * Deduplicate products (remove duplicates across sources)
   */
  deduplicateProducts(products: Product[]): Product[] {
    const seen = new Set<string>();
    const deduplicated: Product[] = [];

    for (const product of products) {
      // Create dedup key from title + price + retailer
      const key = this.createDeduplicationKey(product);

      if (!seen.has(key)) {
        seen.add(key);
        deduplicated.push(product);
      } else {
        this.logger.debug(`Removed duplicate: ${product.title}`);
      }
    }

    this.logger.log(
      `Deduplicated ${products.length} → ${deduplicated.length} products`,
    );

    return deduplicated;
  }

  /**
   * Create deduplication key
   */
  private createDeduplicationKey(product: Product): string {
    const title = product.title.toLowerCase().replace(/[^a-z0-9]/g, '');
    const price = Math.round(product.price);
    const retailer = product.retailer.toLowerCase().replace(/[^a-z0-9]/g, '');

    return `${title}-${price}-${retailer}`;
  }

  /**
   * Filter products by availability and quality
   */
  filterProducts(products: Product[]): Product[] {
    return products.filter((product) => {
      // Must be in stock
      if (!product.inStock) return false;

      // Must have valid price
      if (!product.price || product.price <= 0) return false;

      // Must have title
      if (!product.title || product.title.length < 3) return false;

      // Must have image
      if (!product.imageUrl) return false;

      // Must have product URL
      if (!product.productUrl) return false;

      return true;
    });
  }

  /**
   * Filter products by gender (STRICT enforcement like Python version)
   * Rejects products that clearly belong to wrong gender
   */
  filterByGender(products: Product[], gender?: string): Product[] {
    if (!gender || gender.toLowerCase() === 'unisex') {
      return products;
    }

    const MALE_KEYWORDS = ["men's", 'mens', 'men', 'male', 'boy', 'boys', 'man'];
    const FEMALE_KEYWORDS = ["women's", 'womens', 'women', 'woman', 'female', 'girl', 'girls', 'ladies'];

    const filtered = products.filter((product) => {
      const title = (product.title || '').toLowerCase();
      const url = (product.productUrl || '').toLowerCase();
      const combinedText = `${title} ${url}`;

      if (gender.toLowerCase() === 'men' || gender.toLowerCase() === 'male') {
        // Reject if explicitly women's and NOT also men's
        const hasFemale = FEMALE_KEYWORDS.some((kw) => combinedText.includes(kw));
        const hasMale = MALE_KEYWORDS.some((kw) => combinedText.includes(kw));

        if (hasFemale && !hasMale) {
          return false; // Reject women's products
        }
      } else if (gender.toLowerCase() === 'women' || gender.toLowerCase() === 'female') {
        // Reject if explicitly men's and NOT also women's
        const hasMale = MALE_KEYWORDS.some((kw) => combinedText.includes(kw));
        const hasFemale = FEMALE_KEYWORDS.some((kw) => combinedText.includes(kw));

        if (hasMale && !hasFemale) {
          return false; // Reject men's products
        }
      }

      return true;
    });

    if (filtered.length < products.length) {
      this.logger.debug(
        `Gender filter (${gender}): ${products.length} → ${filtered.length} products`,
      );
    }

    return filtered;
  }

  /**
   * Filter products by price (BEFORE ranking, not after)
   * Matches Python version behavior
   */
  filterByPrice(products: Product[], maxPrice?: number, minPrice?: number): Product[] {
    if (!maxPrice && !minPrice) {
      return products;
    }

    const filtered = products.filter((product) => {
      if (!product.price || product.price <= 0) {
        return true; // Keep products without price info
      }

      if (maxPrice && product.price > maxPrice) {
        return false;
      }

      if (minPrice && product.price < minPrice) {
        return false;
      }

      return true;
    });

    if (filtered.length < products.length) {
      this.logger.debug(
        `Price filter ($${minPrice || 0}-$${maxPrice || '∞'}): ${products.length} → ${filtered.length} products`,
      );
    }

    return filtered;
  }

  /**
   * Filter out category/listing page URLs (not actual product pages)
   * Matches Python version behavior
   */
  filterByUrlType(products: Product[]): Product[] {
    const CATEGORY_PATTERNS = [
      '/category/',
      '/categories/',
      '/collection/',
      '/collections/',
      '/search?',
      '/search/',
      '/shop/',
      '/browse/',
      '/listing/',
      '/products?',
      '/c/',
      '/s/',
    ];

    const filtered = products.filter((product) => {
      const url = (product.productUrl || '').toLowerCase();

      // Reject if URL matches category patterns
      const isCategory = CATEGORY_PATTERNS.some((pattern) => url.includes(pattern));

      if (isCategory) {
        this.logger.debug(`Filtered out category URL: ${url}`);
        return false;
      }

      return true;
    });

    if (filtered.length < products.length) {
      this.logger.debug(
        `URL type filter: ${products.length} → ${filtered.length} products`,
      );
    }

    return filtered;
  }

  /**
   * Apply all filters in the correct order (matches Python pipeline)
   * Order: Gender → Price → URL Type → Quality/Availability → Dedup
   */
  applyAllFilters(
    products: Product[],
    query: SearchQuery,
  ): Product[] {
    let filtered = products;

    // Step 1: Gender filter (STRICT)
    filtered = this.filterByGender(filtered, query.gender);

    // Step 2: Price filter (BEFORE ranking)
    filtered = this.filterByPrice(filtered, query.maxPrice, query.minPrice);

    // Step 3: URL type filter
    filtered = this.filterByUrlType(filtered);

    // Step 4: Quality/availability filter
    filtered = this.filterProducts(filtered);

    // Step 5: Deduplicate
    filtered = this.deduplicateProducts(filtered);

    this.logger.log(
      `Applied all filters: ${products.length} → ${filtered.length} products`,
    );

    return filtered;
  }

  /**
   * Apply diversity to results (don't show too many from same brand/retailer)
   */
  diversifyResults(products: Product[], maxPerBrand: number = 5): Product[] {
    const brandCounts = new Map<string, number>();
    const retailerCounts = new Map<string, number>();
    const diversified: Product[] = [];

    for (const product of products) {
      const brand = product.brand?.toLowerCase() || 'unknown';
      const retailer = product.retailer.toLowerCase();

      const brandCount = brandCounts.get(brand) || 0;
      const retailerCount = retailerCounts.get(retailer) || 0;

      // Skip if we already have too many from this brand/retailer
      if (brandCount >= maxPerBrand || retailerCount >= maxPerBrand * 2) {
        continue;
      }

      diversified.push(product);
      brandCounts.set(brand, brandCount + 1);
      retailerCounts.set(retailer, retailerCount + 1);
    }

    if (diversified.length < products.length) {
      this.logger.debug(
        `Diversified ${products.length} → ${diversified.length} products`,
      );
    }

    return diversified;
  }
}
